# Thippani Nithin — Portfolio

Personal portfolio website generated from my resume.

## Run locally

Open `index.html` in a browser.

## GitHub Pages

1. Create a GitHub repository named `portfolio`.
2. Upload `index.html`, `THIPPANI_NITHIN_RESUME.docx`, and this README.
3. In **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. GitHub will provide the public portfolio URL.
